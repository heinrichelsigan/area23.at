#include<dpmi.h>
#include<go32.h>
#include<pc.h>

#define KEYBD 0x60
#define KBIT  0x80
#define PORT_B 0x61
#define INT_CTL 0x20
#define ENABLE  0x20

static _go32_dpmi_seginfo oldVector,newVector;
static _go32_dpmi_registers regSet;

volatile unsigned char bKeyPressed[128];                  /* keyboard map */
volatile unsigned char bKeyHits[256];                     /* keyhit-counter */

/****************************************************************************
 * Interrupt stuff                                                          *
 ****************************************************************************/

void KeyInterrupt(_go32_dpmi_registers *reg)
{
	unsigned char mask,key;
	key = inportb(KEYBD);

	if (key&128){
		bKeyPressed[key&127] = 0;
	} else {
		bKeyPressed[key] = 1;
		bKeyHits[key]++;
	}
	/* acknowledge stroke */
	mask = inportb(PORT_B);
	outportb(PORT_B, mask | KBIT);
	outportb(PORT_B, mask);

	/* enable interrupts */
	outportb(INT_CTL,ENABLE);
}


/*
	Install interrupts
*/
void InstallInterrupt()
{
	int i;

	/* init int vars */
	for (i=0;i<128;i++){
		bKeyPressed[i] = 0;
		bKeyHits[i] = 0;
	}
	newVector.pm_selector = _go32_my_cs();
	newVector.pm_offset = (int) KeyInterrupt;
	_go32_dpmi_allocate_real_mode_callback_iret(&newVector,&regSet);
	_go32_dpmi_get_real_mode_interrupt_vector(0x9,&oldVector);
	_go32_dpmi_set_real_mode_interrupt_vector(0x9,&newVector);
}

void RemoveInterrupt()
{
	_go32_dpmi_set_real_mode_interrupt_vector(0x9,&oldVector);
	_go32_dpmi_free_real_mode_callback(&newVector);
}

int kbdHasPressed(int k)
{
   if (bKeyHits[k]>0) {
      bKeyHits[k]--;
      return 1;
   } else {
      return 0;
   }
}

void ClearHits()
{
   int i;
   for (i=0; i<128; i++) bKeyHits[i]=0;
}


