/*
					PACMAN

	 A 3-Dimensional pacman-like game.
	 It was programmed with gcc in C, and will be likeley portable onto
	 other systems ....
		 _____________________________________________________________________

	 pacman: A 3-Dimensional pacman-like game.

   Copyright (C) 1995
     Thomas GSCHWIND, Olaf SCHERMANN, Heinrich ELSIGAN

	 This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the Free
   Software Foundation.

	 This program is distributed in the hope that it will be useful, but
	 WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
   or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
   for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
	 675 Mass Ave, Cambridge, MA 02139, USA.


		 _____________________________________________________________________

*/

/* Some features, we supply */
#define FASTKEYBD  /**/
#define DBLE       /**/

/* #define PACMAN_MAZE "data\\maze.fld" /**/
/* #define SPEEDUP 8   /* SPEED FOR GHOSTS ! */
/* ^ not actuell, using struct _paclevels to +se */
/*   speed and level maze */

#define PACMAN_FONT "data\\pacman.fnt"

#include<stdio.h>
#include<stdlib.h>
#include<dos.h>
#include<math.h>
#include<string.h>
#include<ctype.h>
#include<time.h>

#include"vgalib.h" 
#ifdef FASTKEYBD
#include"kbd.h"
#endif
#include"pacman.h"
#include"paclib.h"
#include"mvmnstr.h"
/*#define IDEBUG     /**/
/*#define NOZEN      /**/
/*#define DEBUG      /**/

/*#define SHOWFMAP   /**/
/*#define SHOWWALLS  /**/

#ifdef DEBUG
FILE *dbgf;
#define DBG(str) { str; }
#else
#define DBG(str)
#endif

#ifdef IDEBUG
#define IDBG(x,y,str,c) { vgaPrint(x,y,str,c,0); sleep(2); }
#else
#define IDBG(x,y,str,c)
#endif

/* Allgemeine Konstanten
 */
#define CDVAN 1024 /* Entfernung, ab welcher Objekte verschinden */
#define CDVAN2 10  /* ld(CDVAN) */

#define STEPSZ 8

const char *cmnd;

#ifdef DBLE
/* Our Scene */
char scene[320*200];
#endif

/* AFEYE must be 0 mod 32 */
#define AFEYE 1536

/* Tabellen, f"ur die Distanz auf der X, Y-Achse
 * des aktuellen Blickwinkels, sowie zur Korrektur des
 * Fischaugeneffektes
 */
typedef struct {
  int dx, dy;
  } dir;
dir tdir[60];
dir tview[60][128];

/* Position und Blickwinkel des Betrachters
 * pfwd: Player may go forward?
 */
int px,py,pd;
char trans[256];
vect2 plos;
int pfwd;
char ckeyb;        
int gotyou=0;

/* LEVELS */
#define MAXLEVEL 5 
/* actual MAXLEVEL increment it if you like it ! */
int mylevel;
paclevel lvl[MAXLEVEL];
int supercounter;
/* POINTS */
int points;
char pstr[4];

/* GHOSTS */
#define FASTGHOSTS  /**/  /* Don't touch this switch */
#define MAXGHOSTS 4
#define ZENDBG /**/
#define XGHOST  30
#define YGHOST  30
#define SUPEREND 200
int mx[MAXGHOSTS], my[MAXGHOSTS],
    mxold[MAXGHOSTS], myold[MAXGHOSTS];
ptxtre myghost;
/* Declaration of ghosts */
void moveGhosts(void);
/* Keyboardhandling */
/*union REGS Parameter, Ergebnis; */

unsigned char dqmap[255][8];

/*********************************************************/

void ghost_init(void)            
{
	int i, j, k;
	for (k=0; k<MAXGHOSTS; k++)
	{
		mxold[k]=1;
		myold[k]=1;
	}
}

/* init()
 * init all start values 
 */
void init(void)
{
	int i,j;
	double a1,a2,ab;
	double dx,dy;
	double nx,ny;
	double ratio;

	printf("Initializing...\n");
	ghost_init();
	main_monster();
	paclives=4;
	points=0;
	for(i=0;i<60;i++) {
		dx=sin((double)(i*6)*PI/180);
		dy=-cos((double)(i*6)*PI/180);
		tdir[i].dx=(int)(dx*CDVAN);
		tdir[i].dy=(int)(dy*CDVAN);
		for(j=0;j<128;j++) {
			/* Ablenkung des Strahles */
			/* Distanz nimmt linear zu (Normal) */
			a1=(CDVAN/128)*j+CDVAN/256;
			/* Winkel nimmt lin. zu (Gegenteil d. Fischaugeneffektes) */
/*                      a2=(double)CDVAN*tan( ((double)PI/4)*(j+1)/128 ); */
			ab=a1*1;

			tview[i][j].dx=-dy*ab;
			tview[i][j].dy=+dx*ab;
		}
	}
	for(i=0;i<8;i++) {
		int j;
		for(j=0;j<256;j++) {
			int r,g,b;
			r=((j&0xe0)>>6)/(i+1);
			g=((j&0x1c)>>3)/(i+1);
			b=((j&0x03)>>0)/(i+1);
			dqmap[j][7-i]=((r<<6)&0xE0)|((g<<3)&0x1C)|b;
/*                      dqmap[j][7-i]=j; */
		}
	}
}


/*********************************************************/

#define GETLINE \
  if (fgets(buf,sizeof(buf)-1,fp)==NULL) {\
    fclose(fp);\
		return 2;\
	}

/*********************************************************/
/* Helper functions                                      */
/*********************************************************/
void clearImage(void)
{
    int i, j;
    for (i=0; i<320; i++)
	for (j=0; j<200; j++)
			 vgaSETPIXEL(i,j,0);
}

void prntmap(void)
{
	int i,j;
	for(i=0; i<20; i++) {
		for(j=0; j<20; j++) {
			if (fld[(i<<FLDSZE)+j].hw) vgaSETPIXEL(5+j,170+i,255);
			else vgaSETPIXEL(5+j,170+i,0);
		}
	}
}

void prntghost(ptxtre myghost)
{ 
	int i,j, k;
	char s[80];
	for (k=0; k<paclives; k++) {
		for(i=0;i<(1<<TXTRESZE);i++) {
			for(j=0;j<(1<<TXTRESZE);j++) {
				vgaSETPIXEL(30+k*20+j,175+i,~((*myghost)[j][i]));
			}
		}
	}
	sprintf(s,"Level: %d",mylevel);
	vgaPrint(170,170,s,7,1);
}
void showHelp(void)
{
	int i=0;
	clearImage();
	vgaPrint(75,5,"3D - PACMAN HELP !",255,1);
	vgaPrint(10,30,"Moving Pacman:",255,1);
	vgaPrint(10,40,"   UP: arrow key OR NUM8",255,1);
	vgaPrint(10,50," DOWN: arrow key OR NUM5",255,1);
	vgaPrint(10,60," LEFT: arrow key OR NUM4",255,1);
	vgaPrint(10,70,"RIGHT: arrow key OR NUM6",255,1);
	vgaPrint(10,90," STRAVING LEFT: NUM1",255,1);
	vgaPrint(10,100,"STRAVING RIGHT: NUM3",255,1);
	vgaPrint(60,130,"PRESS 1 TO RETURN TO GAME",255,1);
	while(!i)
		if (bKeyPressed[NUM1] || bKeyPressed[C1]) i++;

	vgaSETPIXEL(160,180,15);
	prntmap();
	prntghost(myghost);
	if (superman)
		prntsuper(1);
}

void trainMode(void)
{
	if (superman==0) 
	{
		superman=1;
		supercounter=0;
		(void) prntsuper(1);
	}
	else 
	{
		superman=0;
		(void) prntsuper(0);
	}
}

int game_menu(void)
{
	int i, j;
	vgaPrint(55,40," [ESC] This menu ",255,1);
	vgaPrint(55,60," 1. Start or continue Level ",255,1);
	vgaPrint(55,80," 2. Show help ",255,1);
	vgaPrint(55,100," 3. Train mode ",255,1);
	vgaPrint(55,120," q. Quit Game ",255,1);
	i=0;
	while(!i)
	{
		if (bKeyPressed[NUM1] || bKeyPressed[C1]) i++;
		if (bKeyPressed[NUM2] || bKeyPressed[C2]) 
			{ showHelp(); i++; }
		if (bKeyPressed[NUM3] || bKeyPressed[C3]) 
			{ trainMode(); i++; }
		if (bKeyPressed[ALPHAq]) { return 1; }
	}
	return 0;
}

/*********************************************************/
/* Keyboard handling                                     */
/*********************************************************/
int dokeybd(void)
{
	dir *td=tdir+pd;
	register int rdx=td->dx>>STEPSZ,rdy=td->dy>>STEPSZ;
 vgaSETPIXEL(5+px/32,170+py/32,0);

#ifdef FASTKEYBD
	if (bKeyPressed[KEY_ESC]) {
		   if (game_menu()) return(0);
	}
	if (bKeyPressed[NUM1]) {
		px+=rdy;
		py-=rdx;
		if ((fld[((py>>TXTRESZE)<<FLDSZE)+(px>>TXTRESZE)].hw)) {
			px-=rdy;
			py+=rdx;
		}
	}
	if (bKeyPressed[NUM3]) {
		px-=rdy;
		py+=rdx;
		if ((fld[((py>>TXTRESZE)<<FLDSZE)+(px>>TXTRESZE)].hw)) {
			px+=rdy;
			py-=rdx;
		}
	}
	if (bKeyPressed[NUM8] && pfwd) {
		px+=rdx;
		py+=rdy;
	}
	if (bKeyPressed[NUM5]) {
		px-=rdx;
		py-=rdy;
		if ((fld[((py>>TXTRESZE)<<FLDSZE)+(px>>TXTRESZE)].hw)) {
			px+=rdx;
			py+=rdy;
		}
	}
	if (bKeyPressed[NUM4]) {
		vgaSETPIXEL(160+(tdir[pd].dx>>7),180+(tdir[pd].dy>>7),0);
		if (--pd<0) pd=59;
		vgaSETPIXEL(160+(tdir[pd].dx>>7),180+(tdir[pd].dy>>7),1);
	}
	if (bKeyPressed[NUM6]) {
		vgaSETPIXEL(160+(tdir[pd].dx>>7),180+(tdir[pd].dy>>7),0);
		if (++pd>59) pd=0;
		vgaSETPIXEL(160+(tdir[pd].dx>>7),180+(tdir[pd].dy>>7),1);
	}
	if (bKeyPressed[ALPHAq]) return 0;
#else
	if (!kbhit()) return 1;
	switch(getkey()) {
	case '8':
		if (pfwd) {
			px+=rdx;
			py+=rdy;
		}
		break;
	case '5':
		px-=rdx;
		py-=rdy;
		if ((fld[((py>>TXTRESZE)<<FLDSZE)+(px>>TXTRESZE)].hw)) {
			px+=rdx;
			py+=rdy;
		}
		break;
	case '4':
		if (--pd<0) pd=59;
		break;
	case '6':
		if (++pd>59) pd=0;
		break;
	case 'q':
		return 0;
	}
#endif
	vgaSETPIXEL(5+px/32,170+py/32,175);

	return 1;
}


/*********************************************************/
/* Main part of engine                                   */
/* Rays/screen are calculated here                       */
/*********************************************************/

/* calcray()
 * Entfernung zu Objekt, das sich in Richtung ,,dx,dy''
 * befindet ausrechnen, sowie dessen Code zur"uckgeben.
 * IN:
 * dx/dy  : distx/y
 */
void calcray(int xpos, int vvx, int vvy)
{
	/* Used for Bresenham-Algorithm */
	int dx=vvx,dy=vvy;
	int dxmy;
	int x,y;
	int gx, gy;
#define OPT_dblchk /**/
#ifdef OPT_dblchk
	/* x-Direction: Check at start/end of square */
	/* y-Direction: Check at start/end of square */
	int chkx,chky;
#else
#define chkx 15
#define chky 15
#endif
	/* y-Direction: North/South */
	/* x-Direction: West/East */
	int rns, rwe;

	/* Line of sight. */
	vect2 los;
	int dist,h,pos;
	int walltxtre;

#ifdef DBLE
	register char *pt=scene+xpos;
#else
	register char *pt=(CURC)->gc_baseaddr+PIXEL_ADDR(xpos,0);
#endif

	los.x=tdir[pd].dx;
	los.y=tdir[pd].dy;

	rns=dy<0?-1:1;
	rwe=dx<0?-1:1;
#ifdef OPT_dblchk
	chky=rns<0?31:0;
	chkx=rwe<0?31:0;
#endif

	dx=abs(dx); dy=abs(dy);
	dxmy=dx-dy;

	x=px;
	y=py;
	walltxtre=fld[((y>>TXTRESZE)<<FLDSZE)+(x>>TXTRESZE)].hw;

	/***************
	 * Trace ray
	 ***************/
	if (dy>dx) {  /* calc y-oriented ray */
		register int c=dy>>1;

		while(walltxtre==0) {
			y+=rns;
			if (c<dy) {
				c-=dxmy;
				x+=rwe;
			} else {
				c-=dx;
			}
/*                      if ((x&31)==chkx || (y&31)==chky) */
			walltxtre=fld[((y>>TXTRESZE)<<FLDSZE)+(x>>TXTRESZE)].hw;
		}
	} else {      /* calc x-oriented ray */
		register int c=dx>>1;

		while(walltxtre==0) {
			x+=rwe;
			if (c<dx) {
				c+=dxmy;
				y+=rns;
			} else {
				c-=dy;
			}
/*                      if ((x&31)==chkx || (y&31)==chky) */
			walltxtre=fld[((y>>TXTRESZE)<<FLDSZE)+(x>>TXTRESZE)].hw;
		}
	}
	if ((x&31)==chkx) {
		pos=(y&31);
	}
	if ((y&31)==chky) {
		pos=(x&31);
	}
#ifndef OPT_xchk
#undef chkx
#undef chky
#endif

	/* Shall we show, where this ray ,,ends''? */
#ifdef SHOWFMAP
	vgaSETPIXEL(5+(x>>5),175+(y>>5),7);
#endif


	/*****************************
	 * Calculate distance
	 *****************************/
	/* Get the normalized distance via Skalar Product */
	dist=(x-px)*los.x+(y-py)*los.y-1;

	/* Disallow walking forward? */
	if (dist<5*CDVAN) pfwd=0;

	/* Calculate hight of wall depending on distance */
	h=((AFEYE<<10)/dist)&~0x01;

	/* Debug Output to verify our model */
	DBG(fprintf(dbgf,"LOS=(%i/%i)\n",los.x,los.y);
	    fprintf(dbgf,"%i: |Vect|=|(%i/%i)|=%i\n",
		    xpos,x-px,y-py,dist);
	    fflush(dbgf););

	/* And draw the wall corresponding to this ray */
	{
		/* txt pointer to current wall-texture */
		char *txt=(*(mtx[walltxtre]))[pos];
		unsigned int yp;
		register unsigned int d,f,n;

		d=((1<<TXTRESZE)<<8)/h;

	DBG(fprintf(dbgf,"h=%d, vx%d vy%d lx%d ly%d\n",
		    h,vvx,vvy,los.x,los.y);
	    fflush(dbgf););
		if(h<160) {
			/***********************
			 * Floor, Ceiling?
			 ***********************/
			char *pf=pt+159*320;
			int hh=159;
			int bc;
			int c1x;
			int c1y;
			
			bc=vvx*los.x+vvy*los.y;
			c1x=(int)(((double)vvx*(double)(AFEYE*CDVAN))/(double)bc);
			c1y=(int)(((double)vvy*(double)(AFEYE*CDVAN))/(double)bc);
			
			n=(160-h)>>1;

			/* Floor & Ceiling */
			do {
				int x=px+(c1x/hh);
				int y=py+(c1y/hh);
				fblock *cb;

				if (x<0)x=0; if(y<0)y=0;
				if (x>(fldx-1)*32-1)x=(fldx-1)*32-1;
				if (y>(fldy-1)*32-1)y=(fldy-1)*32-1;
				cb=&(fld[((y>>SZE_FLTXTRE2)<<FLDSZE)+(x>>SZE_FLTXTRE2)]);

	DBG(fprintf(dbgf,"LOS %d %d %d\n",x,y,cb->fl);
	    fflush(dbgf););
				*pt=(*(mtx[cb->cl]))[x&0x1f][y&0x1f];
				*pf=(*(mtx[cb->fl]))[x&0x1f][y&0x1f];
	DBG(fprintf(dbgf,"LOS %d %d\n",x,y);
	    fflush(dbgf););
				pt+=320;
				pf-=320;
				hh-=2;
			} while (--n);
	DBG(fprintf(dbgf,"LOSfe\n");
	    fflush(dbgf););

			/* Draw wall-texture */
			f=0;
			n=h;
			while(n--) {
				*pt=txt[f>>8];
				pt+=320;
				f+=d;
			}
	DBG(fprintf(dbgf,"LOSse\n");
	    fflush(dbgf););
		} else {
			/***********************
			 * wall only
			 ***********************/
			f=(d*(h-160))>>1;

			/* Draw texture */
	DBG(fprintf(dbgf,"LOS2\n");
	    fflush(dbgf););
			n=160;
			while(n--) {
				*pt=txt[f>>8];
				pt+=320;
				f+=d;
			}
		}
	}
	DBG(fprintf(dbgf,"LOSe\n");
	    fflush(dbgf););
}

/* calcpic()
 * Calculate one screen
 */
void calcpic(void)
{
	dir *ttview=tview[pd];
	int dx=tdir[pd].dx;
	int dy=tdir[pd].dy;

	int i;

	/* HNF - Hessesche Normalvektor-Form
	 * f"ur Berechnung der Distanz des Punktes zum Betrachter
	 *
	 * dx/dy Blickrichtungsvektor
	 * px/py Position des Betrachters
	 * x/y Ort zu dem Entfernung berechnet wird.
	 *
	 * d=(x*dx+y*dy-(px*dx+py*dy))/sqrt(dx^2+dy^2)
	 * sqrt(dx^2+dy^2)=1024=2^10=CDVAN
	 *
	 * VERALTET! Skalarprodukt ist besser!
	 */
	/*  c=(long)px*dx+(long)py*dy; */

	DBG(fprintf(dbgf,"Pos(%i/%i)\n",px,py));

	for(i=0;i<128;i++) {
		/* Calculate left side of screen */
		/* Where's the first wall blocking ray i */
		calcray(159-i,dx-ttview->dx,dy-ttview->dy);
		/* Right side */
		calcray(160+i,dx+ttview->dx,dy+ttview->dy);
		ttview++;
	}
	DBG(fprintf(dbgf,"\n"));
}

void moveGhosts(void)
{  int i;  
       
       
       for(i=0; i<MAXGHOSTS; i++)
       {
		mxold[i]=mx[i];         /* Get old Values */
		myold[i]=my[i];
       }         
	move_monster();

       for(i=0; i<MAXGHOSTS; i++)
       { 
		mx[i]=monster[i].x/32;
		my[i]=monster[i].y/32;
		if (!(mx[i]==mxold[i] && my[i]==myold[i]))
		{
				/* ghosts have changed */
			fld[(my[i]<<FLDSZE)+mx[i]].hw=pl_ghost;  
			fld[(myold[i]<<FLDSZE)+mxold[i]].hw=0;  
		}            

	}
	

return ;
}

/* prntsuper(int spflag) 
 * Prints on display if you are in superman condition or not
 * Parameter tells if begins or ends :)
 */
void prntsuper(int spflag)
{
	if (spflag)
		vgaPrint(260,180,"S",255,1);
	else 
		vgaPrint(260,180," ",0,0);
	return ;
}

/*
 * finish
 * says that the game is finished - positive :) || negative :(
 */
void finished(int how)
{

}

/*
 * freetextures
 * frees all textures 
 */
void freetextures(void)
{
	int i;

	for (i=0; i<MAXTXTRES; i++)
	{
		if (mtx[i]) free(mtx[i]);
	}
return ;
}
/*********************************************************/
/* increase_level 
 * to increase level and free all textures 
 */
void increase_level(void)
{
	int i, j;
	char ck;
	mylevel++;
	
	if (mylevel>5) 
	{
		(void) finished(1);
	}

	(void) freetextures();    
	/* free textures do get new on */
	/* in next level */
#ifdef FASTKEYBD
	RemoveInterrupt();
#endif
	if (system("pcxread.exe data\\level.pcx")!=0) 
	{
		fprintf(stderr,"Cannot exec \"readpcx\"\n");
		fprintf(stderr,"Press 'q' to quit, other to continue!\n");
		if ((ck=getkey())=='q')
		{
			vgaText();
			exit(255); /* DOS ERROR */
		}
	}
	/* show new level Pic and print statisitiX */
#ifdef FASTKEYBD
	InstallInterrupt();
#endif
}
/*********************************************************/

int pacmain(int vecc, char **vecv)
{
	int i,j;
	int strt, end, frm=0;
	int err;
	char buf[256];
	/* Here updated by zen */
	int gx, gy, endflg=1;
	int idz;
	int zenpill;

	int i1, j1;
	struct time t1, t2;
	/* End of Update */
	DBG(dbgf=fopen("anim.dbg","w"));
	cmnd=vecv[0];
	supercounter=0;
	/* Read maze, with level counter */
	if ((err=readfld(lvl[mylevel].maze))!=0) {
		fprintf(stderr,"%s: Error %i, when reading %s\n",
		cmnd,err,lvl[mylevel].maze);
		exit(1);
	}

	/* Read Ghosts */
	if ((err=readtxtre("data/ghost1.gh",&myghost))<0) {
		vgaText();
		fprintf(stderr,"ghosterr %d\n",err);
		exit(1);
	}

	init();
	vgaGraph();

#ifdef FASTKEYBD
	InstallInterrupt();
#endif
/*        vgaPrint(10,10,"3D-Pacman V0.0",1,0);
	sprintf(buf,"%p\n",(CURC)->gc_baseaddr);
	vgaPrint(10,20,buf,1,0);
	sleep(1); */

	clearImage();
	vgaSETPIXEL(160,180,15);
	prntmap();
	prntghost(myghost);
	strt=time(NULL);
	px=304;
	py=592;
	/* Eventuell statt Winkel die Distanz auf der X und jene auf der
	 * Y-Achse verwenden.
	 * Verringert ev. Speicherbedarf.
	 */
	pd=15;

	/* Simplifies debugging :-) */
	zenpill=pl_fld_pills;
	
	calcpic();
#ifdef DBLE
	memcpy((CURC)->gc_baseaddr+PIXEL_ADDR(0,0),
		scene,
		160*320);
#endif
	if (!mylevel) game_menu();
	gettime(&t1);
	do {
#ifndef FASTGHOSTS
		gettime(&t2);
		/* ghost polling routine depends on level */
		if ((abs(t2.ti_hund-t1.ti_hund))>lvl[mylevel].speedup) 
#endif
		{
#ifndef FASTGHOSTS
			t1.ti_hund=t2.ti_hund;
			/* move all SPEEDUP ms ghosts */
			moveGhosts();
#else
			moveGhosts();
#endif
			idz++;
		}
		frm++;
		pfwd=1;
		if (supercounter>SUPEREND)
		{
			supercounter=0;
			superman=0;
			(void) prntsuper(0);
		}
		if (superman)
			supercounter++;

		i=fld[((py>>TXTRESZE)<<FLDSZE)+(px>>TXTRESZE)].fl;
		if(i==pl_pill||i==pl_power) {
			fld[((py>>TXTRESZE)<<FLDSZE)+(px>>TXTRESZE)].fl=pl_nopill;
			pl_fld_pills--, points++;
			sprintf(pstr,"%d",points);
			vgaPrint(170,185,"    ",0,0);
			vgaPrint(170,185,pstr,255,1);
			if (pl_fld_pills<=0)
			{
				/* Goto next level and free all textures */
				/* and reset the game */
				lvl[mylevel].count=1;
			}
			if (i==pl_power) {
				superman=1;
				supercounter=0;
				(void) prntsuper(1);
			}
		}

		calcpic();
#ifdef DBLE
		memcpy((CURC)->gc_baseaddr+PIXEL_ADDR(0,0),
			scene,
			160*320);
#endif
	} while(dokeybd()&&!lvl[mylevel].count);

	end=time(NULL);
	if (lvl[mylevel].count)
	{
		/* vgaText(); */
		(void) increase_level();
		return 1;
	}
#ifdef FASTKEYBD
	RemoveInterrupt();
#endif
	vgaText();

	DBG(fclose(dbgf));

	printf("PILL: %d, now: %d\n",zenpill,pl_fld_pills);

	return 0;
}

/* main */
/* I (and probably you, like short main routines in C :) */
int main(int argc, char **argv)
{
	char ck;
	int speed;
	char level[80];
	int i, err=0;
	/* INIT LEVEL DATAS HERE */
	mylevel=0;
	
	if (argc>1)
	{       
		fprintf(stderr,"Usage: %s\n",argv[0]);
		exit(1);
	}
	/* Tom you can argc, argv to set level or something like that */
	/* Exmaple pacman -level.\data\mylevel -speed10 */
	strcpy(lvl[0].maze,"data\\maze.fld");
	strcpy(lvl[1].maze,"data\\maze1.fld");
	strcpy(lvl[2].maze,"data\\maze2.fld");
	strcpy(lvl[3].maze,"data\\maze3.fld");
	strcpy(lvl[4].maze,"data\\maze4.fld");
	for(i=0;i<MAXTXTRES;i++) {
		mtx[i]=NULL;
	}
	for (i=0; i<MAXLEVEL; i++)
	{
		lvl[i].count=0;
	}
	lvl[0].speedup=4;
	lvl[1].speedup=3;
	lvl[2].speedup=2;
	/* NIGHTMARE OPTION */
	lvl[3].speedup=1;
	lvl[4].speedup=0;
	
	/* Read font */
	if ((err=vgaLoadFont(PACMAN_FONT))!=0) {
		vgaText();
		fprintf(stderr,"%s: Error %i, when reading Font\n",cmnd,err);
		exit(1);
	}
	if (system("pcxread.exe data\\pacman.pcx")!=0) 
	{
		fprintf(stderr,"Cannot exec \"readpcx\"\n");
		fprintf(stderr,"Press 'q' to quit, other to continue!\n");
		if ((ck=getkey())=='q')
		{
			freetextures();
			vgaText();
			exit(255); /* DOS ERROR */
		}
	}
	
	while(pacmain(argc, argv)); 
	/* If pacmain returns 1 start it again, in new level */
	/* with new maze and textures, otherwise end this game */
	vgaText();
	printf("                     3D-PACMAN WAS WRITTEN 1995 by\n");        
	printf("                            Thomas Gschwind   \n");
	printf("                             Olaf Schermann   \n");
	printf("                            Heinrich Elsigan  \n\n");
	printf("email:\n\ntom@logic.tuwien.ac.at\nolaf@cslab.tuwien.ac.at\n");
	printf("zen@hell.cg.tuwien.ac.at\n\n\n");
	printf("ThanX 4 playing this game :).\n");
	(void) freetextures();
	

return 0;
}
