/***************************************************************
     MOVE_MONSTER

     Routine fuer CG23 Projekt Pacman zur automatischen steuerung
     der Monster im Labyrinth
**************************************************************/



#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <conio.h>
#include <dos.h>
#include "mvmnstr.h"
#include "paclib.h"

#define MAX_MONSTER 4

struct  monster_struct monster[MAX_MONSTER];

char key;
extern int px,py;
int schaas,superman;
int old_x, old_y;
int paclives;
int points;

extern ptxtre myghost;

int gotcha(const char *got,int which)
{
	
	vgaPrint(108,72,"*************",7,1);
	vgaPrint(108,80,got,7,1);
	vgaPrint(108,88,"*************",7,1);
	sleep(2);
	if (which)
	{
		if (--paclives) {
			main_monster();
			clearImage();
			prntmap();
			prntghost(myghost);
	
		} 
		else
		{
			vgaText();
			/* no cleanup make it l8r */
			RemoveInterrupt();
			freetextures();
			exit(0);
		}
	}
	else {
		points+=25;
		main_monster();
		clearImage();
		prntmap();
		prntghost(myghost);
	}
}



void move_monster()
{
int monster_id, dx,dy;

void choose_dir()
{
int possible_dir[4], max_pos_dir, current_dir, change_dir, i;

int pacman_near()
{
int i, pac_dir, the_way,the_way_id, dx,dy,x,y,zx,zy;

     monster[monster_id].dir=possible_dir[random()%max_pos_dir];

     pac_dir=0;
     if (monster[monster_id].x/32==px/32) pac_dir+=30;
     if (monster[monster_id].y/32==py/32) pac_dir+=15;

     if((pac_dir==15)||(pac_dir==30))
       { /* continue */
	 if ((pac_dir==30)&&(monster[monster_id].y/32>py/32)) pac_dir=0;
	 else if ((pac_dir==15)&&(monster[monster_id].x/32>px/32)) pac_dir=45;

	 the_way=0xff;
	 for (i=0;i<max_pos_dir;i++)
	     if (possible_dir[i]==pac_dir) { the_way=pac_dir; the_way_id=i; }
	 if (the_way!=0xff)
	   { /*continue */
	     switch(the_way)
	      {
		case 0: dx=0; 
		dy=-1; 
		break;
		case 15:
		dx=1;
		dy=0;
		break;
		case 30:dx=0; 
		dy=1;
		break;
		case 45:
		dx=-1; 
		dy=0;
		break;
		default:dx=0; dy=0;
		break;
	      } /* switch */
	     x=monster[monster_id].x/32;
	     y=monster[monster_id].y/32;
	     zx=px/32;
	     zy=py/32;
	     if (dx)
		{
		  while( ((x+=dx)!=zx)&&(fld[(y<<FLDSZE)+x].hw==0));
		  if (x==zx) {  if (!superman)
				{ 
				  monster[monster_id].dir=the_way;
				  return 1;
				}
				  else if (max_pos_dir>1)
				  { possible_dir[the_way_id]=possible_dir[max_pos_dir-1];
				    max_pos_dir--;
				  }
				  return 0;
			      }
		  else return 0;
		}
	     else if (dy)
		  {
		    while( ((y+=dy)!=zy)&&(fld[(y<<FLDSZE)+x].hw==0));
		    if (y==zy) {  if (!superman)
				  { 
				    monster[monster_id].dir=the_way;
				    return 1;
				  }
				  else if (max_pos_dir>1)
				  { possible_dir[the_way_id]=possible_dir[max_pos_dir-1];
				    max_pos_dir--;
				  }
				  return 0;
				}
		    else return 0;
		  }
		  else return 0;
	   }  /* if the_way */
	 else return 0;
       } /* if pac_Dir... */
     else return 0;

}/* pacman near() */

  max_pos_dir=0;
  current_dir=monster[monster_id].dir;
  change_dir=1;

  if (fld[(monster[monster_id].y/32-1<<FLDSZE)+monster[monster_id].x/32+0].hw==0) { possible_dir[max_pos_dir]=0; max_pos_dir++; }
  if (fld[(monster[monster_id].y/32+0<<FLDSZE)+monster[monster_id].x/32+1].hw==0) { possible_dir[max_pos_dir]=15; max_pos_dir++; }
  if (fld[(monster[monster_id].y/32+1<<FLDSZE)+monster[monster_id].x/32+0].hw==0) { possible_dir[max_pos_dir]=30; max_pos_dir++; }
  if (fld[(monster[monster_id].y/32+0<<FLDSZE)+monster[monster_id].x/32-1].hw==0) { possible_dir[max_pos_dir]=45; max_pos_dir++; }

  for (i=0;i<max_pos_dir;i++)
  {
    if (possible_dir[i] == current_dir) change_dir--;  /* chang dir nur wenns nicht weiter geht */
    if (((possible_dir[i] + 60 - current_dir)%30) ==15) change_dir++; /* oder es abzweigungen gibt */
  } /* for i */

  if(change_dir && max_pos_dir)
  {
     if(!pacman_near())
     monster[monster_id].dir=possible_dir[random()%max_pos_dir];
     if (((monster[monster_id].dir + 60 - current_dir)%60) ==30)   /* minimize go_back propability */
	monster[monster_id].dir=possible_dir[random()%max_pos_dir];
     if (((monster[monster_id].dir + 60 - current_dir)%60) ==30)   /* minimize go_back propability */
	monster[monster_id].dir=possible_dir[random()%max_pos_dir];
  } /* if change_dir */


} /* move_monster.choose_dir() */



  for(monster_id=0; monster_id < MAX_MONSTER; monster_id++)
  {
     if ((monster[monster_id].x%32==16)&&(monster[monster_id].y%32==16))
	choose_dir();

     switch(monster[monster_id].dir)
     {
     case 0: dx=0; dy=-1;
	     break;
     case 15:dx=1; dy=0;
	     break;
     case 30:dx=0; dy=1;
	     break;
     case 45:dx=-1; dy=0;
	     break;
     default:dx=0; dy=0;
	     break;
     } /* switch */

     old_x=monster[monster_id].x;
     old_y=monster[monster_id].y;

     monster[monster_id].x+=dx;
     monster[monster_id].y+=dy;

     if((monster[monster_id].x/32!=old_x/32)||(monster[monster_id].y/32!=old_y/32))
     {  vgaSETPIXEL(5+old_x/32,170+old_y/32,0);
	vgaSETPIXEL(5+monster[monster_id].x/32,170+monster[monster_id].y/32,123);         
     }


     if ((monster[monster_id].x/32==px/32)&&(monster[monster_id].y/32==py/32))
     {    
	if (superman)
	gotcha("* GOT GHOST *",0);
	else
	gotcha("*  GOTCHA!  *",1);
     }

  } /* for monster...*/
} /* move_monster */


void main_monster()
{
  /* randomize(); */
  /* not proper could be better */
  monster[0].x=240;
  monster[0].y=240;
  monster[0].dir=15;
  monster[1].x=240;
  monster[1].y=240;
  monster[1].dir=15;
  monster[2].x=240;
  monster[2].y=240;
  monster[2].dir=15;
  monster[3].x=240;
  monster[3].y=240;
  monster[3].dir=15;

  schaas=0;

  superman=0;
} 

