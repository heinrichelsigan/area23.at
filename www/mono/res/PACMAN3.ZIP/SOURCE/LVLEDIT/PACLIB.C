#include"paclib.h"
#include<stdio.h>
#include<ctype.h>

int pl_comment='#';
int pl_text=1;
char pl_ghost;
char pl_pill;
char pl_nopill;
char pl_power;
char pl_fld_pills;

fblock fld[(1<<FLDSZE)<<FLDSZE];
int fldx,fldy;

/* Textures */
ptxtre mtx[MAXTXTRES];
int mtxp;

/****************************************************************/
/*** Basic File Ops                                           ***/
/****************************************************************/

/* fgetcomment(FILE *fp)
 */
int fgetcomment(FILE *fp,char *c)
{
	int ch;
	
	/* Skip whitespace and comments */
	do {
		ch=fgetc(fp);
		/* Skip Comment? */
		if (ch==pl_comment && ch!=EOF) {
			while((ch=fgetc(fp))!=EOF && ch!='\n');
		}
		/* unexpected EOF? */
		if (ch==EOF) return -1;
	} while(isspace(ch));
	ungetc(ch,fp);
	return 0;
}

/* fgeti
 * read integer from fp
 */
int fgeti(FILE *fp,int *n)
{
	int ch;

	*n=0;
	if (fgetcomment(fp,NULL)<0) return -1;
	if ((ch=fgetc(fp))==EOF) return -1;

	if (!isdigit(ch)) {
		ungetc(ch,fp);
		return -2;
	}

	/* read number */
	do {
		*n=*n*10+(ch-'0');
	} while((ch=fgetc(fp))!=EOF && isdigit(ch));

	if (ch!=EOF) ungetc(ch,fp);

	return 0;
}

/****************************************************************/
/*** Complex File Ops                                         ***/
/****************************************************************/

int pl_showtxtre(texture *txt)
{
	int i,j;
	for(i=0;i<(1<<TXTRESZE);i++) {
		for(j=0;j<(1<<TXTRESZE);j++) {
			printf("%c",(*txt)[j][i]);
		}
		printf("\n");
	}
}

/* readtxtre
 *   Read a texture and allocate its colors
 */
int readtxtre(const char *fn, texture **txt)
{
	FILE *fp;
	int i,j,k,err;
	int ch;
	char buf[256],*bp;
#ifdef SHOWWALLS
	int d,f,x,y;
#endif
	char *p;

	int nc,cc;                     /* Number of colors in pixmap, cols/char */
	unsigned char col[256];        /* Bitmap-Palette2My-Palette translation */
	char bwname[256],colname[256]; /* Name of color */
	char *bwp;
	texture *t;

	if ((*txt=(ptxtre)malloc(sizeof(texture)))==NULL) {
		fclose(fp);
		return -1;
	}
	t=*txt;

	if ((fp=fopen(fn,"r"))==NULL) {
		return -2;
	}

	/* Get Colors */
	if (fgeti(fp,&nc)<0) return -3;
	if (fgeti(fp,&cc)<0) return -4;

	if (cc!=1) {        /* Just 1 character/color supported */
		fclose(fp);
		return -5;
	}

	fgets(buf,sizeof(buf),fp);
	for(i=0;i<nc;i++) {
		int r,g,b;
		fgets(buf,sizeof(buf),fp);

		bp=buf;
		while(*bp!='#' && *bp!='\0') bp++;
		if (*bp++=='\0') return -6;
		ch=*bp;

		while(*bp!=',' && *bp!='\0') bp++;
		if (*(bp++)==0) return -6;
		bwp=bwname;
		while(*bp!=',' && *bp!='\0') *bwp++=*bp++;
		if (*(bp++)==0) return -6;

		strcpy(colname,bp);
/*		if (vgaColor2RGB(colname,&r,&g,&b)<0) return -7;*/
		col[ch]=(r&0xE0)|((g&0xE0)>>3)|((b&0xC0)>>6);

	}

	for(i=0;i<(1<<TXTRESZE);i++) {
		for(j=0;j<(1<<TXTRESZE);j++) {
			ch=fgetc(fp);
			(*t)[j][i]=col[ch];
#ifdef SHOWWALLS
			vgaSETPIXEL(j,i,col[ch]);
#endif
		}
		while((ch=fgetc(fp))!='\n');
	}

#ifdef SHOWWALLS
	for(i=10;i<500;i+=(i>100)?7:1) {
		d=((1<<TXTRESZE)<<8)/i;
		for(k=0;k<(1<<TXTRESZE);k++) {
			x=k;
			y=80-i/2;
			f=(((1<<TXTRESZE)<<8)-d*i)/2;
			for(j=0;j<i;j++,y++) {
				if(y>0 && y<160) {
					vgaSETPIXEL(x,y,(**(mtx[mtxp]))[(k<<TXTRESZE)+(f>>8)]);
				}
				f+=d;
			}
		}
	}
#endif

	return 0;
}

/* readfld
 *   Read field and its textures and allocate the texture's colors
 */
int readfld(const char *fn)
{
	FILE *fp;
	int l,i,bm,err;
	int ch,hw,vw;
	char trans[256];
	char buf[256];

	if ((fp=fopen(fn,"r"))==NULL) {
		return -1;
	}

	fldx=-1; fldy=-1; bm=-1;
	if ((err=fgeti(fp,&fldx)<0) ||
	    (err=fgeti(fp,&fldy)<0) || 
	    (err=fgeti(fp,&bm)<0)) {
		if (pl_text) {
			printf("Error=%d, Sze=(%d/%d), Textures: %d\n",
			       err,fldx,fldy,bm);
		}
		fclose(fp);
		return -2;
	}

	/* Get # Color-Bitmaps */
	if (bm>MAXTXTRES) {
		fclose(fp);
		return -3;
	}

	if (fgetcomment(fp,NULL)<0) return -4;

	trans['.']=0;
	for(mtxp=1;mtxp<=bm;mtxp++) {
		if (fgets(buf,sizeof(buf),fp)==NULL) return -5;
		buf[strlen(buf)-1]='\0';

		trans[*buf]=mtxp;
		printf("%s\n",buf+2);
		if ((err=readtxtre(buf+2,&(mtx[mtxp])))<0) return -128+err;
/*              pl_showtxtre(mtx[mtxp]);*/
	}
	pl_fld_pills=0;
	pl_ghost=trans['G'];
	pl_pill=trans['o'];
	pl_nopill=trans['N'];
	pl_power=trans['P'];

	printf("Field %d %d %d %d\n",pl_ghost,pl_pill,pl_nopill,pl_power);
	
	/* Get Field */
	for(l=0; l<fldy; l++) {
		for(i=0; i<fldx; i++) {
			hw=fgetc(fp);
			fld[(l<<FLDSZE)+i].hw=trans[hw];
			vw=fgetc(fp);
			fld[(l<<FLDSZE)+i].vw=trans[vw];
			ch=fgetc(fp);
			fld[(l<<FLDSZE)+i].cl=trans[ch];
			ch=fgetc(fp);
			fld[(l<<FLDSZE)+i].fl=trans[ch];
			if (trans[hw] && (ch=='P'||ch=='o')) pl_fld_pills++;
/*#define START_FIELD /**/
#ifdef START_FIELD
			if (pl_text) {
				if (trans[hw]||trans[vw]) printf("%c%c",hw,vw);
				else printf("  ");
			} else {
				vgaSETPIXEL(i,l,(trans[hw]&&trans[vw])?100:0);
			}
#endif
		}
		while((ch=fgetc(fp))!='\n');
#ifdef START_FIELD
		if (pl_text) printf("\n");
#endif
	}
	fclose(fp);
	
#ifdef START_FIELD
	sleep(2);
#endif
	return 0;
}

