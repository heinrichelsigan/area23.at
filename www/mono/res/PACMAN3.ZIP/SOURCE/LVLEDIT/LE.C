#include<stdio.h>
#include"../pacman3/paclib.h"

int wx,wy;
int px,py;

const char *fsrc, *fdst;

#define ESC '\033'

void clearscrn()
{
	printf("%c[2J",ESC);
	fflush(stdout);
}

void gotoxy(int x,int y)
{
	printf("%c[%d;%dH",ESC,y,x);
	fflush(stdout);
}

void printwin(int wx, int wy)
{
	int i,j;
	
       	gotoxy(1,1);
	for(j=wy;j<fldy && j-wy<20;j++) {
		for(i=0;i<fldx;i++) {
			char ch=fld[(j<<FLDSZE)+i].hw;
			if (i!=px||j!=py) {
				printf("%c",ch?ch:' ');
			} else {
				printf("%c",(fld[(j<<FLDSZE)+i].hw)?'*':'.');
			}
		}
		printf("\n");
	}
}

void loadfld(void)
{
	int i,j;
        FILE *fp;
	
	fp=fopen(fdst,"r");
	
	for(j=0;j<fldy;j++) {
		for(i=0;i<fldx;i++) {
			char h,v,c,f;
			h=fgetc(fp);
			v=fgetc(fp);
			c=fgetc(fp);
			f=fgetc(fp);
			fld[(j<<FLDSZE)+i].hw=h;
			fld[(j<<FLDSZE)+i].vw=v;
			fld[(j<<FLDSZE)+i].cl=c;
			fld[(j<<FLDSZE)+i].fl=f;
		}
		while(fgetc(fp)!='\n');
	}
	
	fclose(fp);
}

void savefld(void)
{
	int i,j;
        FILE *fp;
	
	fp=fopen(fdst,"w");
	
	for(j=0;j<fldy;j++) {
		for(i=0;i<fldx;i++) {
			char ch=fld[(j<<FLDSZE)+i].hw;
			fprintf(fp,"%c%c%c%c",
			        ch?ch:'.',' ',
				fld[(j<<FLDSZE)+i].cl,
				fld[(j<<FLDSZE)+i].fl);
		}
		fprintf(fp,"\n");
	}
	
	fclose(fp);
}

setpills()
{
	int i,j;
	
        for(j=0;j<fldy;j++) {
		for(i=0;i<fldx;i++) {
			fld[(j<<FLDSZE)+i].cl='o';
			fld[(j<<FLDSZE)+i].fl='o';
		}
	}
}

main(int argc, char **argv)
{
	int x=0;
        int i,j;
	
	if (argc<3) exit(1);
/*	fsrc=argv[1];*/
	fldx=atoi(argv[1]);
	fldy=atoi(argv[2]);
	fdst=argv[3];
	
	
        for(j=0;j<fldy;j++) {
		for(i=0;i<fldx;i++) {
			fld[(j<<FLDSZE)+i].cl=0;
			fld[(j<<FLDSZE)+i].fl=0;
			fld[(j<<FLDSZE)+i].hw=0;
			fld[(j<<FLDSZE)+i].vw=0;
		}
	}
	
       	clearscrn();
       	wx=0; wy=0;
	px=0; py=0;
	
       	do {
		if (px<0) px=0;
		if (px>=fldx) px=fldx-1;
		if (py>=fldy) py=fldy-1;
		if (py<0) py=0;
		if (px<wx) wx=px;
		if (py<wy) wy=py;
		if (px>=wx+20) wx=px-20;
		if (py>=wy+20) wy=py-20;
		printwin(wx,wy);
		gotoxy(60,1);
		printf("Pos: %d/%d",px,py);
		gotoxy(60,2);
		printf("^=%c _=%c",
		       fld[(py<<FLDSZE)+px].cl,fld[(py<<FLDSZE)+px].fl);
		fflush(stdout);
		gotoxy(px-wx+1,py-wy+1);
		i=getkey();
		switch(i) {
		case '8':
			py-=1;
			break;
		case '2':
			py+=1;
			break;
		case '4':
			px-=1;
			break;
		case '6':
			px+=1;
			break;
		case 'q':
			x=1;
			break;
		case 'b':
			fld[(py<<FLDSZE)+px].hw=getkey();
			px=px+1;
			break;
		case 'B':
			fld[(py<<FLDSZE)+px].hw=0;
			px=px+1;
			break;
		case 'c':
			fld[(py<<FLDSZE)+px].cl=getkey();
			px=px+1;
			break;
		case 'f':
			fld[(py<<FLDSZE)+px].fl=getkey();
			px=px+1;
			break;
		case 'o':
			setpills();
			break;
		case 'l':
			loadfld();
			break;
		case 's':
			savefld();
			break;
		default:
			printf("Aetsch!\n");
		}
	} while(!x);
}
