/**********************************************************/
/* My own vgaLibrary                                      */
/* (c) Thomas Gschwind 95                                 */
/**********************************************************/

#include<stdio.h>
#include<stdlib.h>

#include<string.h>
#include"vgalib.h"
#include<grx.h>

vgaScreen vgaScrn;
char *vgaChrs=NULL;
char *vgaDisp=NULL;
vgaRGB vgaPalette[256];

struct mode_entry {
    short w,h,c,mode_no;
};

static struct mode_entry mode_table[] = {
    { 80,  25,  2,   0x07 },    /* text modes */
    { 40,  25,  16,  0x01 },
    { 80,  25,  16,  0x03 },
    { 320, 200, 16,  0x0d },    /* graphics modes */
    { 640, 200, 16,  0x0e },
    { 640, 350, 16,  0x10 },
    { 640, 480, 16,  0x12 },
    { 800, 600, 16,  (-1) },    /* we have to trust the user's mode number on this */
    { 320, 200, 256, 0x13 }
};

static int set_BIOS_mode(int BIOSno,int wdt,int hgt,int col,int *modep)
{
	struct mode_entry *mp = mode_table;
	int count = sizeof(mode_table) / sizeof(mode_table[0]);
	REGISTERS reg;
	int retval;

	for( ; --count >= 0; mp++) {
	    if(mp->w != wdt) continue;
	    if(mp->h != hgt) continue;
	    if(mp->c != col) continue;
	    if(wdt >= 320) {
		if(mp->mode_no != (-1)) BIOSno = mp->mode_no;
		retval = (col == 16) ? (GRD_VGA | GRD_4_PLANES) : (GRD_VGA | GRD_8_PLANES);
		*modep = GR_width_height_color_graphics;
	    }
	    else {
		BIOSno = mp->mode_no;
		retval = GRD_VGA | GRD_4_PLANES;
		*modep = GR_width_height_text;
	    }
	    reg.r_ax = BIOSno;
	    int10(&reg);
	    _GrScreenX = wdt;
	    _GrScreenY = hgt;
	    return(retval);
	}
	return(-1);
}

static void int_setmode(int mode,int BIOSno,int width,int height,int colors)
{
	long planesize;
	int  flags;
	int  planes;

    printf("MouseUnInit\n");
/*    (*_GrMouseUnInit)(); */
#ifdef _SINGLE_MODE_
    printf("Single not set\n");
	for(flags = 0; flags < NumOfHandlers; flags++) {
	    if(_GrResetValues[flags] == NULL) continue;
	    *(_GrResetAddresses[flags]) = _GrResetValues[flags];
	}
#endif
	if((mode >= GR_80_25_text) && (mode <= GR_width_height_color_graphics)) {
	    memset(&_GrVidPage,0,sizeof(GrContext));
	    flags = (BIOSno > 0) ?
		set_BIOS_mode(BIOSno,width,height,colors,&mode) :
		(int)_GrLowSetMode(mode,width,height,colors);
	    _GrCurrentMode = mode;
	    switch(flags & GRD_TYPE_MASK) {
	      case GRD_VGA:
		_GrVidPage.gc_baseaddr = (char far *)VGA_FRAME;
		_GrAdapterType = GR_VGA;
		break;
	      case GRD_EGA:
		_GrVidPage.gc_baseaddr = (char far *)EGA_FRAME;
		_GrAdapterType  = GR_EGA;
		break;
	      case GRD_HERC:
		_GrVidPage.gc_baseaddr = (char far *)HERC_FRAME;
		_GrAdapterType  = GR_HERC;
		break;
	      case GRD_8514A:
		_GrAdapterType  = GR_8514A;
		break;
	      case GRD_S3:
		_GrAdapterType  = GR_S3;
		break;
	      default:
		_GrLowSetMode(GR_default_text,0,0,0);
		fputs("GrSetMode: unknown adapter type in driver\n",stderr);
		exit(1);
	    }
	    switch(planes = (flags & GRD_PLANE_MASK)) {
#if (GRXPLANES & 16)
	      case GRD_16_PLANES:
		if(_GrAdapterType != GR_VGA) goto Default;
		_GrDriverIndex = VGA32K_DRIVER;
		_GrNumColors = 32768;
		break;
#endif
#if (GRXPLANES & 8) || (GRXPLANES & MODE_8514A)
	      case GRD_8_PLANES:
	      case GRD_8_F_PLANES:
		switch(_GrAdapterType) {
		  case GR_VGA:
		    _GrDriverIndex = VGA256_DRIVER;
		    break;
		  case GR_8514A:
		    _GrDriverIndex = IBM_8514A_DRIVER;
		    break;
		  case GR_S3:
		    _GrDriverIndex = S3_DRIVER;
		    break;
		  default:
		    goto Default;
		}
		_GrNumColors = 256;
		break;
#endif
#if (GRXPLANES & 4)
	      case GRD_4_PLANES:
		if(_GrAdapterType == GR_HERC) goto Default;
		_GrDriverIndex = VGA16_DRIVER;
		_GrNumColors = 16;
		break;
#endif
#if (GRXPLANES & 1)
	      case GRD_1_PLANE:
		if(_GrAdapterType != GR_HERC) goto Default;
		_GrDriverIndex = HERC_DRIVER;
		_GrNumColors = 2;
		break;
#endif
	      default:
	      Default:
		_GrLowSetMode(GR_default_text,0,0,0);
		fputs("GrSetMode: bad color plane # in driver\n",stderr);
		exit(1);
	    }
	    if(mode >= GR_320_200_graphics) {
		planesize = GrPlaneSize(_GrScreenX,_GrScreenY);
#ifdef _MAXVIDPLANESIZE
		if((_GrAdapterType != GRD_8514A) &&
		   (_GrAdapterType != GRD_S3) &&
		   (_GrAdapterType != GRD_W9000) &&
		   (planesize > _MAXVIDPLANESIZE)) {
#ifdef _MAXBIGVIDPLSIZE
		    if(planesize <= _MAXBIGVIDPLSIZE) {
			_GrVidPage.gc_baseaddr = (char far *)BIG_VGA_FRAME;
			_GrBigFrameBuffer = TRUE;
			if((flags & GRD_PAGING_MASK) == GRD_RW_64K) {
			    _GrCanBcopyInBlit = TRUE;
			    _GrRdOnlyOffset   = BIG_RDONLY_OFF;
			    _GrWrOnlyOffset   = BIG_WRONLY_OFF;
			}
			else {
			    _GrCanBcopyInBlit = FALSE;
			    _GrRdOnlyOffset   = 0L;
			    _GrWrOnlyOffset   = 0L;
			}
		    }
		    else
#endif
		    {
			_GrLowSetMode(GR_default_text,0,0,0);
			fputs("GrSetMode: graphics mode too big\n",stderr);
			exit(1);
		    }
		}
		else
#endif
		if(planesize < 0x10000L) {
		    _GrCanBcopyInBlit = TRUE;
		    _GrBigFrameBuffer = FALSE;
		    _GrRdOnlyOffset   = 0;
		    _GrWrOnlyOffset   = 0;
		}
		else if((flags & GRD_PAGING_MASK) == GRD_RW_64K) {
		    _GrCanBcopyInBlit = TRUE;
		    _GrBigFrameBuffer = TRUE;
		    _GrRdOnlyOffset   = RDONLY_OFF;
		    _GrWrOnlyOffset   = WRONLY_OFF;
		}
		else {
		    _GrCanBcopyInBlit = FALSE;
		    _GrBigFrameBuffer = TRUE;
		    _GrRdOnlyOffset   = 0;
		    _GrWrOnlyOffset   = 0;
		}
		_GrVidPage.gc_onscreen   = TRUE;
		_GrVidPage.gc_frameaddr  = BASE_ADDRESS(&_GrVidPage);
		_GrVidPage.gc_lineoffset = GrLineOffset(_GrScreenX);
		_GrVidPage.gc_xmax = _GrVidPage.gc_xcliphi = _GrScreenX - 1;
		_GrVidPage.gc_ymax = _GrVidPage.gc_ycliphi = _GrScreenY - 1;
		_GrContext = _GrVidPage;
		switch(_GrNumColors) {
		    case 16:  _GrP4Init(flags & GRD_MEM_MASK); break;
#ifndef _INLINE256
		    case 256: if(_GrAdapterType == GR_VGA) _GrP8Init(planes); break;
#endif
		    default:  break;
		}
		GrRefreshColors();
		_GrMouseDrawn = 0;
		_GrMouseCheck = 0;
	    }
	}
}

void vgaGraph(void)
{
    int i;
    int_setmode(GR_320_200_graphics,0x13,320,200,256);

    GrSetRGBcolorMode();
    for(i=0;i<256;i++) {
        GrSetColor(i,(i&0xE0)>>6,(i&0x1C)>>6,(i&0x03)>>0);
    }
}

void vgaText(void)
{
	GrSetMode(GR_80_25_text);
}

void vgaAddFont(char *charset)
{
	vgaChrs=charset;
}

int vgaLoadFont(const char *font)
{
	FILE *fp;
	unsigned int c,i,j;
	char buf[256],t;

	char *Font;

	if ((fp=fopen(font,"r"))==NULL) return -1;

	/* Alloc Font Space */
	Font=(char*)malloc(8*256UL);
	while(fgets(buf,sizeof(buf),fp)) {
		c=strtol(buf,NULL,0);
		for(i=0;i<8;i++) {
			fgets(buf,sizeof(buf),fp);
			for(j=0,t=0;j<8;j++) t|=(buf[j]=='.')?0:1<<j;
			Font[8*c+i]=t;

		}
	}
	fclose(fp);

	vgaChrs=Font;

	return 0;
}

int vgaUnloadFont(const char *font)
{
	free(vgaChrs);
	vgaChrs=NULL;
	return 0;
}

void vgaDisplay(char *display)
{
	vgaDisp=display;
}

#define vgaFGETS(buf,fp) while(fgets(buf,sizeof(buf),fp) && buf[0]=='#'); \

int vgaShowPic(char *fn)
{
	FILE *fp;

	char buf[256],*bp;
	int n,i,j,x,y;

	register unsigned char *p;

	if ((fp=fopen(fn,"r"))==NULL) return -1;

	vgaFGETS(buf,fp);
	if (strncmp(buf,"$begin colormap",15)) return -3;

	do {
		vgaFGETS(buf,fp);
		bp=buf;
		n=strtol(bp,&bp,16);
		vgaPalette[n].r=strtol(bp,&bp,0);
		vgaPalette[n].g=strtol(bp,&bp,0);
		vgaPalette[n].b=strtol(bp,&bp,0);
	} while(strncmp(buf,"$end colormap",13));

	vgaFGETS(buf,fp);
	if (strncmp(buf,"$begin size",10)) return -4;
	vgaFGETS(buf,fp);
	bp=buf;
	x=strtol(bp,&bp,0);
	y=strtol(bp,&bp,0);
	vgaFGETS(buf,fp);
	if (strncmp(buf,"$end size",8)) return -5;

/*      vgaFGETS(buf,fp);
	if (strncmp(buf,"$begin picture",14)) return -6;
*/
	vgaSetPalette(vgaPalette,0,256);
	for(j=0;j<y;j++) {
		p=vgaDisp+320*j;
		for(i=0;i<x;i++,p++) {
			if ((n=fgetc(fp))==EOF) return -7;
/*                      *p=n; 
*/
			GrPlot(i,j,n);
		}
	}

	(void) fclose(fp);
	return 0;
}

void vgaDisp2Scrn(void)
{
/*      memcpy(vgaScrn.vmem,vgaDisp,320*200);
*/
}

void vgaVLine(int x, int y0, int y1, int c)
{
/*      register char *rpt;
	register int rn=y1-y0+1,rc=c;

	rpt=vgaDisp+320*y0+x;
	for(;rn>0;rn--,rpt+=320)
		*rpt=rc;
*/
	GrVLine(x,y0,y1,c);
}

void vgaPrint(int x, int y, const char *s, int c, int b)
{
	int i,j;
	while(*s) {
		for(j=0;j<8;j++) {
			for(i=0;i<8;i++) {
/*                              if (vgaChrs[(*s)*8+j]&(1<<i)) vgaDisp[320*(y+j)+x+i]=c;
				else if (b!=-1) vgaDisp[320*(y+j)+x+i]=b;
*/
		if (vgaChrs[(*s)*8+j]&(1<<i)) GrPlot(x+i,y+j,c);
		else if (b!=-1) GrPlot(x+i,y+j,b);
			}
		}
		x+=8;
		s++;
	}
}

void vgaSetPalette(vgaRGB *p, int s, int n)
{
/*      asm {
		les dx,p                                /* Get address of colormap */
/*              mov bx,s                                /* Get first color index   */
/*              mov cx,n                                /* Get Number of indexes   */
/*              mov ax,1012h            /* Set block of color registers function */
/*              int 10h
	}
*/
}

static int getnum(char **str, int *num)
{
  while(isspace(**str)) (*str)++;
	*num=atoi(*str);
  while(isdigit(**str)) (*str)++;
	return 0;
}

int vgaColor2RGB(const char *name, int *r, int *g, int *b)
{
	char buf[256],*bp;
	const char *i;
	FILE *fp;

	while((fp=fopen(vgaRGB_TXT,"r"))==NULL) {
	       
		fprintf(stderr,"Cannot open rgb.txt\n");
		/* return -1; */
	}

	while(fgets(buf,sizeof(buf),fp)) {
		if((i=strstr(buf,name))!=NULL) {
			bp=buf;
			getnum(&bp,r);
			getnum(&bp,g);
			getnum(&bp,b);
			while(isspace(*bp)) bp++;
			i=name;
			while(*i==*bp && *i!='\0') {i++; bp++;}

			while(isspace(*i)) i++;
			while(isspace(*bp) || *bp=='\n') bp++;
			if (*i=='\0' && *bp=='\0') {
				fclose(fp);
				return 0;
			}
		}
	}
	fclose(fp);
	return -1;
}
