/****************************************************************/
/*       																												*/
/* A PCX loader from A. Fuhrmann (CG Institute) 							  */
/*                                                  						*/
/* Simply adapted by us to load PCX-Images,                     */
/* (too few time for us to write it with gcc, so we took it)    */
/* Better using a functional lib, than to write a new one :)    */
/*       																												*/
/****************************************************************/
#include <stdio.h>
#include "vga256.h"
#include <alloc.h>
#include <conio.h>
#include <dos.h>
#include <string.h>
#include <stdlib.h>

/* #define DEBUG /**/

#define COMPRESSNUM     0xc0
#define BUFFERSIZE      16000   // assume 16k Buffer

static unsigned long int ulnBCounter=BUFFERSIZE;
static unsigned char ucBuffer[BUFFERSIZE];


struct PCXHeader
{
	unsigned char   ucSignature;
	unsigned char   ucVersion;
	unsigned char   ucEncoding;
	unsigned char   ucBitsPerPixel;
	int             nXMin;
	int             nYMin;
	int             nXMax;
	int             nYMax;
	int             nDPIH;
	int             nDPIV;
	unsigned char   ucPal16[16][3];
	unsigned char   ucReserved;
	unsigned char   ucNumOfPlanes;
	int             nBytesPerLinePerPlane;
	int             nPalInfo;
	int             nHScreenSize;
	int             nVScreenSize;
	unsigned char   nDummy[127-74+1];
};
typedef struct PCXHeader PCXHEADER;
typedef struct PCXHeader far* lpPCXHEADER;

char ReadByte(FILE* MyFile);

unsigned char far* ReadPCX(char far* lpszFileName,
					unsigned char far* ucDestination,
					int* nXSize, int* nYSize,
					unsigned char far* lpPal)
/* reads PCXFile into Buffer ucDestination, new Pal in lpPal. (lpPal must exist !) */
/* if ucDestination==NULL Mem is Allocated by Function                             */
/* Function returns far Ptr to Data                                                        */
/* Warning : No ErrorChecking for wrong Formats...                                 */
{
	FILE            *InputFile;
	PCXHEADER       MyHeader;
	unsigned char   ucByte;
	unsigned int    unCount;
	unsigned int    unActualPos=0;
	int             a;

	ulnBCounter=BUFFERSIZE; /* bugfix dieter 94-05-04 */

	if(!(InputFile=fopen(lpszFileName,"r+b")))
	{
		printf("\nERROR PCXRead(fopen)");
		return(NULL);
	}
	if(1!=fread(&MyHeader,sizeof(PCXHEADER),1,InputFile))
	{
		printf("\nERROR PCXRead: File seems to be corrupted");
		return(NULL);
	}

	if(MyHeader.ucBitsPerPixel!=8)
	{
		printf("\nERROR PCXRead: This PCXType is not suported");
		return(NULL);   /* wrong PCXType */
	}

	/* calculate PicSize */
	*nXSize=MyHeader.nXMax-MyHeader.nXMin+1;
	*nYSize=MyHeader.nYMax-MyHeader.nYMin+1;

	/* if no userdefined Destination allocate destination */
	if(!(ucDestination))
	{                          /* far */
		if(!(ucDestination=farmalloc((unsigned long int)
								((unsigned long int)*nXSize*
								(unsigned long int)*nYSize))))
		{
			printf("\nERROR PCXRead: Out of Memory");
			return(NULL);
		}
	}
	unCount=0;

	while(unActualPos<(*nXSize* *nYSize))
	{
		ucByte=ReadByte(InputFile);
		if((ucByte&COMPRESSNUM)==COMPRESSNUM)
		{
			unCount=ucByte&0x3f;
			ucByte=ReadByte(InputFile);
			for(a=0;a<unCount;a++)
				ucDestination[unActualPos++]=ucByte;
		}
		else
		{
			ucDestination[unActualPos++]=ucByte;
		}
	}
	/* read Pal */

	fseek(InputFile,-(256*3+1),SEEK_END);
	fread(&ucByte,sizeof(char),1,InputFile);
	if(ucByte==12)
	{
		if(1!=fread(lpPal,256*3,1,InputFile))
		{
			printf("\nERROR PCXRead : Unexpected EOF");
			return(NULL);
		}
		for(a=0;a<3*256;a++) lpPal[a]>>=2;
	}
	else
	{
		printf("\nWARNING PCXRead No Pal ID found:%d!",ucByte);
	}
	fclose(InputFile);

	return(ucDestination);
}


char ReadByte(FILE* MyFile)
// reads 1 Byte from MyFile using buffered IO
{
	unsigned char ucByte;

	if(ulnBCounter<BUFFERSIZE) /* some Bytes still loaded */
	{
		return(ucBuffer[ulnBCounter++]);
	}
	else    /* fetch Buffer */
	{
		fread(ucBuffer,BUFFERSIZE*sizeof(char),1,MyFile);
		ulnBCounter=0;
	}
	return(ucBuffer[ulnBCounter++]);
}

int main(int argc, char **argv)
{
	char far*       hpPicData;
	int             nX, nY;
	unsigned char   Pal[256*3];
	int             i,j;

	if (argc<2)
	{
			(void) fprintf(stderr,"Usage: %s <pcxfile> \n",
											argv[0]);
			return (1);
	}


	if(!(hpPicData=ReadPCX(argv[1],NULL,&nX,&nY,
				(unsigned char far*)Pal)))
	{
		(void) fprintf(stderr,"\n%s: error while reading %s!\n",
				argv[0],argv[1]);
		exit(10);
	}
	else
	{

		GraphicMode();
		SetAllPalette(Pal,0,256);
		ClearPage(0);
		for (i=0; i<nX; i++)
			for(j=0; j<nY; j++)
			{
				 SetPixel(i,j,(hpPicData[i+j*nX]));  //i +j*nX
			}

		sleep(4);
		TextMode();
		(void) farfree(hpPicData);
	}
return(0);
}
